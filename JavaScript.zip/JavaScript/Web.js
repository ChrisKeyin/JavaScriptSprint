fetch("JS.json")
  .then(response => response.json())
  .then(data => {
    data.Games.forEach(game =>{
        for (const consoleName in game) {
            console.log(`${consoleName}: ${game[consoleName]}`);
        }
    })

  })
  function getConsoleName(data) {
    return data.Games.map(game => Object.keys(game)[0]);
  }

  function getConsoleCounts(data) {
    return data.Games.map(game => Object.values(game)[0]);
  }

  function describeGames(data) {
    const names = getConsoleNames(data);
    const counts = getConsoleCounts(data);

    let description = "Game console description:\n";
    names.forEach((name, index) => {
      description +- `${name}: ${counts[index]}\,`;

    });
    

  }










